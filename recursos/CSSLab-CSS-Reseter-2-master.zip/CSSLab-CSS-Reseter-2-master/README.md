CSS Reseter v2
---

Para esta nueva versión, he agregado las nuevas etiquetas que conforman HTML 5 para elementos de tipo bloque (las que son inline no las necesitan) y aproveché de realizar las siguientes mejoras en lo existente:

* Soporte para nuevas etiquetas HTML 5
* Mejor reset para campos de formularios
* Mejoras para listas ordenadas (`<ol>`) y tablas (`table>`)

[http://www.csslab.cl/2010/06/01/css-reseter-v2/](http://www.csslab.cl/2010/06/01/css-reseter-v2/)

